import os
from dotenv import load_dotenv

load_dotenv()

AZURE_CV_TRAINING_ENDPOINT = "https://makewayna.cognitiveservices.azure.com/"
AZURE_CV_TRAINING_KEY = "CICQ8ToTRqNYXGh5hK3ivZr8Lkwz7WCGRN52zH8DR2QagBxhFk1aJQQJ99BLACYeBjFXJ3w3AAAJACOGnmFy"
AZURE_CV_PREDICTION_ENDPOINT = "https://makewayna-prediction.cognitiveservices.azure.com/"
AZURE_CV_PREDICTION_KEY = "8RiUhDsqBInQeLsxFKvmSA4IpwPv7HIr5GJ50aQHlvtgqmImDMhOJQQJ99BLACYeBjFXJ3w3AAAIACOGuBwP"
AZURE_CV_PROJECT_ID = "0f5eb5b6-6337-42b6-ad77-8b9b2538b238"
AZURE_CV_PUBLISHED_NAME = os.getenv("Intrusion_detector", "Iteration1")

AZURE_FACE_ENDPOINT = "https://azurecustomviz.cognitiveservices.azure.com/"
AZURE_FACE_KEY = os.getenv("AZURE_FACE_KEY", "")
AZURE_FACE_PERSON_GROUP_ID = os.getenv("AZURE_FACE_PERSON_GROUP_ID", "agricultural-workers")

AZURE_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=customvizblob;AccountKey=/EO0sxEIDVouaJS+R/NJch6KR6SVdU4g66bVDUxxXado1AbEZjEoXLlcXKXZBdec+EkKCHQB7T87+AStcMEvAA==;EndpointSuffix=core.windows.net"
AZURE_STORAGE_CONTAINER = "customblob"

SUPABASE_URL = os.getenv("VITE_SUPABASE_URL", "")
SUPABASE_KEY = os.getenv("VITE_SUPABASE_ANON_KEY", "")

PERSON_CONFIDENCE_THRESHOLD = float(os.getenv("PERSON_CONFIDENCE_THRESHOLD", "0.60"))
MASK_CONFIDENCE_THRESHOLD = float(os.getenv("MASK_CONFIDENCE_THRESHOLD", "0.80"))
HUGGINGFACE_API_KEY = os.getenv("HUGGINGFACE_API_KEY", "")
