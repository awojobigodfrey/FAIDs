from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class EventCreate(BaseModel):
    event_type: str
    reason: str
    person_name: Optional[str] = None
    image_url: str
    confidence: Optional[float] = None
    timestamp: datetime

class Event(BaseModel):
    id: str
    event_type: str
    reason: str
    person_name: Optional[str]
    image_url: str
    confidence: Optional[float]
    timestamp: datetime
    created_at: datetime

    class Config:
        from_attributes = True

class EventStats(BaseModel):
    total_intrusions: int
    total_recognized: int
    recent_events: list[Event]

class PushSubscriptionCreate(BaseModel):
    endpoint: str
    p256dh: str
    auth: str
